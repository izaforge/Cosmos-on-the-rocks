/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const main: (a: number, b: number) => number;
export const __externref_table_alloc: () => number;
export const __wbindgen_export_1: WebAssembly.Table;
export const __wbindgen_exn_store: (a: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_export_6: WebAssembly.Table;
export const _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h6e841d3f98db6dcd: (a: number, b: number) => void;
export const _dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__heeca3b7d0a25574b: (a: number, b: number, c: number) => void;
export const closure35445_externref_shim: (a: number, b: number, c: any) => void;
export const _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__he2a9b12e741f07d0: (a: number, b: number) => void;
export const closure35448_externref_shim: (a: number, b: number, c: any, d: any) => void;
export const _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__hf7a15beea59b438a: (a: number, b: number) => void;
export const closure160116_externref_shim: (a: number, b: number, c: any) => void;
export const __wbindgen_start: () => void;
